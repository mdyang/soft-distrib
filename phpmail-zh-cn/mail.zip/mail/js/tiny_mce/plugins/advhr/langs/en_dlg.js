tinyMCE.addI18n('en.advhr_dlg',{
width:"Width",
size:"Height",
noshade:"No shadow"
});